#! /bin/bash 
picom &
nitrogen --restore &
urxvtd -q -o -f &
